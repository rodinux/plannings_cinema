(function() {
  $(function() {
    return $('.datepicker').datepicker;
  });

}).call(this);
